const addSpareparts_list = input => {
  return {
    type: 'sparepartslist',
    payload: input,
  };
};

export default addSpareparts_list